﻿$Host.UI.RawUI.BackgroundColor = "Black"
$Host.UI.RawUI.ForegroundColor = "White"
Clear-Host
$expectedSize = 5568178176  # замените это значение на фактический размер файла в байтах
$filePath = "$env:TEMP\WinInstaller\ru-ru_windows_11_consumer_editions_version_24h2_x64_dvd_784471d8.iso"
$aria2Path = "$env:TEMP\WinInstaller\aria2\aria2c.exe"
$downloadUrl = "https://drive.massgrave.dev/ru-ru_windows_11_consumer_editions_version_24h2_x64_dvd_784471d8.iso"

if (Test-Path -Path $filePath) {
    $fileSize = (Get-Item $filePath).length
    if ($fileSize -eq $expectedSize) {
        Write-Host "Файл существует и имеет правильный размер. Ничего не делаем."
    } else {
        Write-Host "Размер файла не совпадает. Начинаем загрузку..."
        Start-Process -FilePath $aria2Path -ArgumentList "-x 16 -s 16 -d $env:TEMP\WinInstaller -o ru-ru_windows_11_consumer_editions_version_24h2_x64_dvd_784471d8.iso $downloadUrl" -Wait
        Write-Host "Загрузка завершена."
    }
} else {
    Write-Host "Файл не найден. Начинаем загрузку..."
    Start-Process -FilePath $aria2Path -ArgumentList "-x 16 -s 16 -d $env:TEMP\WinInstaller -o ru-ru_windows_11_consumer_editions_version_24h2_x64_dvd_784471d8.iso $downloadUrl" -Wait
    Write-Host "Загрузка завершена."
}
